#!/bin/bash
gksudo 'python SPtester.pyw "rootcheck=no"'
