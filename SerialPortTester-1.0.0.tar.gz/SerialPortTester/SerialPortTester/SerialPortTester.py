from PyQt4.QtGui import *
from PyQt4.QtCore import QString,SIGNAL

import serial,exceptions,time
from serial.tools import list_ports
from ReaderThread.ReaderThread import ReaderThread

import icon_rc

class SerialPortTester(QDialog):
	
	def __init__(self,parent=None):
		super(SerialPortTester,self).__init__(parent)
		
		##port variables
		self.port = None
		self.port_name = None
		self.port_baudrate = 1200
		self.port_parity = serial.PARITY_NONE
		self.port_reader = ReaderThread() #this is edited later here
		self.port_timeout = 1
		self.baudrates = [1200, 1800, 2400, 4800, 9600, 19200, 38400]
		self.parity = [	serial.PARITY_NONE, 
						serial.PARITY_EVEN, 
						serial.PARITY_ODD, 
						serial.PARITY_SPACE, 
						serial.PARITY_MARK]
		self.parity_str = [ 'None',
							'EVEN',
							'ODD',
							'SPACE',
							'MARK']
		
		#upper portion - label,combobox,check button
		self.up = QHBoxLayout()
		self.up.addWidget(QLabel("Available Ports : "))
		
		self.available_ports = QComboBox()
		self.up.addWidget(self.available_ports)
		
		self.check_available_ports = QPushButton("Check");
		self.up.addWidget(self.check_available_ports)
		
		#left side configuration box
		self.left = QVBoxLayout()
		self.left.addWidget(QLabel("Configure COM port:"))
		
		self.l1 = QHBoxLayout()
		self.l1.addWidget(QLabel("Port Name : "))
		self.port_name_box = QLabel("None")
		self.l1.addWidget(self.port_name_box)
		self.left.addLayout(self.l1)
				
		self.l2 = QHBoxLayout()
		self.l2.addWidget(QLabel("Baudrate  : "))
		self.port_baudrate_box = QComboBox()
		for b in self.baudrates :
			self.port_baudrate_box.addItem(QString.number(b))
		self.l2.addWidget(self.port_baudrate_box)
		self.left.addLayout(self.l2)
		
		self.l3 = QHBoxLayout()
		self.l3.addWidget(QLabel("Parity    : "))
		self.port_parity_box = QComboBox()
		for p in self.parity_str :
			self.port_parity_box.addItem(p)
		self.l3.addWidget(self.port_parity_box)
		self.left.addLayout(self.l3)
		
		self.left.addStretch()
		
		self.open_port = QPushButton('Open Port')
		self.close_port = QPushButton('Close Port')
		self.show_in_hex = QCheckBox("Show Read Data in HEX format")
		self.clear_read_data = QPushButton("Clear Read Data")
		self.l4 = QHBoxLayout()
		self.left.addWidget(self.show_in_hex)
		self.l4.addWidget(self.open_port)
		self.l4.addWidget(self.close_port)
		self.left.addLayout(self.l4)
		self.left.addWidget(self.clear_read_data)
		
		#right chat box - write , read
		self.right = QVBoxLayout()
		self.right.addWidget(QLabel('Write to device :'))
		self.write_box = QLineEdit()
		self.right.addWidget(self.write_box)
		self.right.addWidget(QLabel('Read data :'))
		self.read_box = QTextEdit()
		self.right.addWidget(self.read_box)
		
		#midle layout - configuration , chatting
		self.mid = QHBoxLayout()
		self.mid.addLayout(self.left)
		self.mid.addLayout(self.right)
		
		
		#close button
		self.down = QVBoxLayout()
		self.close_button = QPushButton("Close")
		self.down.addWidget(self.close_button)
		self.status_box = QLabel("status : ")
		self.down.addWidget(self.status_box)
		
		self.mother = QVBoxLayout()
		self.mother.addLayout(self.up)
		self.mother.addLayout(self.mid)
		self.mother.addLayout(self.down)
		
		#final decoration
		self.setLayout(self.mother)
		self.setWindowIcon(QIcon("icon.png"))
		self.setMinimumSize(450,350)
		self.setStyleSheet("QDialog {background-color:rgb(243,244,154);\
									border-style: outset;\
									border-radius:5px;\
									border-color:black;\
									border-width:2px;}\
							QPushButton {background-color:#58d5f4;\
									font-size:16px;\
									border-style: inset;\
									border-radius:5px;\
									border-color:black;\
									border-width:1px;\
									padding:2px;}\
							QPushButton:hover{color:red;\
									background-color:rgb(51,198,125);}\
							QCheckBox {font-size:14px;}\
							QComboBox{color:black;\
									border:1px solid black;\
									border-radius:8px;\
									padding:2px;}\
							QLabel{font-size:14px;}\
							QLineEdit{border:1px solid black;\
									border-radius:8px;\
									padding:2px;}\
							QTextEdit{font-size:14px;\
									color:blue;\
									border:2px solid black;\
									border-radius:10px;\
									padding:2px;}")
		
		#make close connection
		self.connect(self.close_button,
					SIGNAL("clicked()"),
					self.Close)
		#connection to check available port
		self.connect(self.check_available_ports,
					SIGNAL("clicked()"),
					self.check_ports)
					
		#connection to change port name
		self.connect(self.available_ports,
					SIGNAL("currentIndexChanged(int)"),
					self.change_port_name)
		#connection to change baudrate
		self.connect(self.port_baudrate_box,
					SIGNAL("currentIndexChanged(int)"),
					self.change_port_baudrate)
		#connection to change parity
		self.connect(self.port_parity_box,
					SIGNAL("currentIndexChanged(int)"),
					self.change_port_parity)
		#connection to open port
		self.connect(self.open_port,
					SIGNAL("clicked()"),
					self.open_selected_port)
		#connection to close port
		self.connect(self.close_port,
					SIGNAL("clicked()"),
					self.close_selected_port)
		#connection to write
		self.connect(self.write_box,
					SIGNAL("returnPressed()"),
					self.write_to_port)
					
		#connection to update data
		self.connect(self.port_reader,
					SIGNAL("dataFoundSignal(QString)"),
					self.update_data)
					
		#connection to clear read data
		self.clear_read_data.clicked.connect(self.clear_read_box)
		
	def Show(self):
		self.show()

	def Close(self):
		self.close()
	
	def closeEvent(self,event) :
		if self.port is not None :
			try :
				self.port.close()
			except :
				pass
		self.port_reader.Terminate()
		
	def check_ports(self):
		self.port_list = list(list_ports.comports())
		for port in self.port_list :
			self.available_ports.addItem(port[0])
		self.status_box.setText('status : '+QString.number(len(self.port_list))+' ports found')
	
	def change_port_name(self,index):
		try :
			self.port_name_box.setText(self.port_list[index][0])
			self.port_name = self.port_list[index][0]
		except Exception as e :
			QMessageBox.warning(self,
							'Error',
							e.msg)
							
	def change_port_baudrate(self,index):
		try :
			self.port_baudrate = self.baudrates[index]
			#print self.port_baudrate
		except Exception as e :
			QMessageBox.warning(self,
							'Error',
							e.msg)

	def change_port_parity(self,index):
		try :
			self.port_parity = self.parity[index]
			#print self.port_parity
		except Exception as e :
			QMessageBox.warning(self,
							'Error',
							e.msg)
							
	def open_selected_port(self):
		try :
			self.port = serial.Serial( self.port_name,
								baudrate=self.port_baudrate,
								parity=self.port_parity,
								timeout=self.port_timeout)
			if self.port.isOpen() :
				self.port.close()
			self.port.open()
			self.status_box.setText('status : '+self.port_name+' port opened')
			print self.port.name , self.port.baudrate , self.port.parity ,self.port.stopbits, self.port.bytesize
			
			self.port_reader.port = self.port
			self.port_reader.start()
		except serial.SerialException as e:
			QMessageBox.warning(self,
							'Error',
							str(e))
		except exceptions.RuntimeError as e :
			QMessageBox.warning(self,
							'Error',
							str(e))
		except :
			pass
							
	def close_selected_port(self) :
		try :
			if self.port.isOpen() :
				self.port.close()
				time.sleep(0.1)
			self.port_reader.Terminate()
			self.status_box.setText("status : port closed ...")
		except Exception as e :
			QMessageBox.warning(self,
							'Error',
							str(e))
		except serial.SerialException as e:
			QMessageBox.warning(self,
							'Error',
							str(e))
		except :
			pass
			
	def write_to_port(self):
		try :
			if self.port.isOpen() :
				data = str(self.write_box.text())
				#data += "\n"
				self.port.write(data.encode('ascii'))
				#print self.port.write(data.encode('ascii'))
				self.status_box.setText('status : '+QString.number(len(data))+' characters written')
				self.write_box.setText("")
			else :
				QMessageBox.warning(self,
							'Warning',
							'Port is Not Opened')			
		except Exception as e :
			QMessageBox.warning(self,
							'Error',
							str(e))
		except serial.SerialException as e:
			QMessageBox.warning(self,
							'Error',
							str(e))
		except :
			pass
			
	def update_data(self,data):
		if not self.show_in_hex.isChecked() :
			self.read_box.append(data)
		else :
			s = '['
			i = 0
			try :
				d = str(data).encode('ascii')
				while i <len(d):
					s+=(' '+hex(ord(d[i])))
					i+=1
				s+=']'
				self.read_box.append(s)
			except Exception as e :
				QMessageBox.warning(self,
							'Error',
							str(e))

	def clear_read_box(self):
		self.read_box.setText("")
