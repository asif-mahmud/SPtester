from PyQt4.QtGui import *
from PyQt4.QtCore import *

import serial,time

class ReaderThread(QThread):
	
	dataFoundSignal = pyqtSignal(str)
	
	def __init__(self) :
		QThread.__init__(self)		
		self.port = None
		self.data = None
		self.isActive = True
		
	def Terminate(self):
		self.isActive = False
	
	def run(self) :
		self.isActive = True
		while self.isActive:
			self.data = None 
			while self.data is None :
				if self.port.isOpen() :
					self.data = self.port.readline()
			if len(self.data) > 0 :
				#print self.data
				self.dataFoundSignal.emit(self.data)
				#print 'signal emited'
				time.sleep(0.2)
		

