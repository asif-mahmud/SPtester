from cx_Freeze import setup, Executable

includes = ["sip","re","atexit","PyQt4"]

setup(
    name = "PySerialv1.0.0",
    version = "1.0.0",
    description = "Python serial port communicator software",
    author = "Asif Mahmud Shimon",
    executables = [Executable(
        script="SPtester.pyw")],
    options = {"build_exe" : {"includes" : includes,
                              "icon":"icon.png",
                              "include_files":["icon.png",
                                               "run.sh"]}})
